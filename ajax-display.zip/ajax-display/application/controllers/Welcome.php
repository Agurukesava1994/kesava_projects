<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	
	public function index()
	{
		$this->load->view('welcome_message');
	}

	public function add(){

		$this->load->model('Login_model', 'model');

		$username = $password =  $status = '';

		if(isset($_REQUEST['username'])){

			$username = $_REQUEST['username'];

		}

		if(isset($_REQUEST['password'])){

			$password = $_REQUEST['password'];

		}

		$status = $this->model->insert_data($username, $password);

		echo $status;exit;

	}

	public function get(){

		$this->load->model('Login_model', 'model');

		$username = $password =  '';

		$data = [];

		if(isset($_REQUEST['username'])){

			$username = $_REQUEST['username'];

		}

		if(isset($_REQUEST['password'])){

			$password = $_REQUEST['password'];

		}

		$data['result'] = $this->model->get_data($username, $password);

		echo json_encode($data);exit;

	}
}
