<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model {

        public function insert_data($username, $password){

            $status = 0;

            $data = [

                'username' => $username,
                'password' => $password

            ];
            
            $this->db->trans_start();

            $this->db->insert('user', $data);

            $this->db->trans_complete();

            if ($this->db->trans_status() === FALSE)
            {
                    $this->db->trans_rollback();

                    return $status;
            }
            else
            {
                    $this->db->trans_commit();
                    
                    return $status = '1';
            }
        }

        public function get_data($username, $password){

                $sql = "SELECT * from user where username = '$username' and password = '$password' ";
                $query = $this->db->query($sql);
                $result = $query->row_array();
                return $result;
        }
}   